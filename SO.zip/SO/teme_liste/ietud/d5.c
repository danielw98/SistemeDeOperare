/*
D5. (4 puncte) Program care primeste ca argument in linia de comanda un
 director si sterge (recursiv) toata arborescenta cu originea in el.
*/
/*
Ce ar trebui sa fac:
	- Sa obtin fiecare intrare din directorul curent. (ex: vector intrare[n])
	- Pt fiecare intrare[i]: parcurg intregul director, si fac un vector de intrare[]
	- Daca este fisier sau director gol, il sterg.
Ce nu stiu:
	- Cum aflu numarul fisierelor din directorul curent.
	- Cum sterg un fisier de orice tip (inclusiv director gol)
	- 
*/



void rm_r(char* dirName){

	DIR *pd;
	struct dirent *pde;
	char cale[256];
	char specificator[256];

	


	if((pd = opendir(dirName)) == NULL){
		return -1;
	}
	else{
	
		int lengthD = dirLength(pd);
		int lengthF = filesLength(pd);

		for(int i = 0; i < lengthD; i++){
			// functia prelucreaza(..) asigura stergerea recursiva a tuturor componentelor
			prelucreaza(dir[i]);		
		}
		for(int i = 0; i < lengthF; i++){
			stergeFisier(fisier[i]);		
	
		}
	}
	sterge(pd);		
}


int main(int argc, char **argv){

	rm_r(argv[1]);
	

	

	return 0;
}
