#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <sys/stat.h>

void dir(char *directory, int depth);

int main(int argc, char **argv)
{

	puts("Finding Directories");

	if(argc==2)
		dir(argv[1], 0);
	else
		dir(".", 0);

	return 0;
}


void dir(char *directory, int depth)
{

	DIR *folder;
	struct dirent *entry;
	struct stat filestat;


	/* Change to the named directory */
	if(chdir(directory))
	{
		fprintf(stderr, "Error changing to %s\n", directory);
		exit(1);
	}
	
	/* Open the directory */
	folder = opendir(".");
	if(folder == NULL)
	{
		fprintf(stderr, "Unable to read directory %s\n", directory);
		exit(1);
	}


	printf("%*s%s\n", depth*2, " ", directory);
	/* Look for a subdirectory */
	while( (entry=readdir(folder)) )
	{
		stat(entry->d_name, &filestat);
		// look for only directories

		if(S_ISDIR(filestat.st_mode) )
		{
			// skip the . and .. entries
			if(strcmp(entry->d_name, ".") == 0 || strcmp(entry->d_name, "..") == 0)
				continue;

			// recurse to the found directory
			dir(entry->d_name, depth+1);
		}
	}

	chdir("..");
	closedir(folder);

}
