#include <stdio.h>
#include <dirent.h>

int main(int argc, char **argv)
{
	DIR *folder;
	struct dirent *entry;
	int files = 0;

	folder = opendir(argv[1]);

	if(folder == NULL){
		perror("Unable to read directory");
		return(1);
	}

	while( (entry = readdir(folder)) ){
		files++;
		printf("File %3d: %s, %d\n",
				files,
				entry->d_name,
				entry->d_type
				);
	}

	closedir(folder);
	return 0;
}
