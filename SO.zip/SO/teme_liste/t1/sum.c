#include <stdio.h>
#include <stdlib.h>

int getNumarElemente(FILE *f)
{
	fseek(f, 0, SEEK_END);
	int length = ftell(f);
	fseek(f, 0, SEEK_SET);

	return length / sizeof(int);
}


int getNumarLinii(FILE *f, int nrElemente)
{
	int offset = nrElemente - 1;
	int nrLinii;
	fseek(f, offset * sizeof(int), SEEK_SET);
	fread(nrLinii, sizeof(int), f);
	fseek(f, 0, SEEK_SET);
}


int getNumarColoane(int nrElemente, int m)
{
	return (nrElemente - 1) / m;
}


int** new(int m, int n)
{
	int **A = (int**) malloc (m * sizeof(int*));

	int i, j;
	for(i = 0; i < m; i++)
	{
		A[i] = (int*) malloc(n * sizeof(int));
		for(j = 0; j < n; j++)
		{
			A[i][j] = 0;
		}
	}

	return A:
}

int get(FILE *f, int i, int j)
{
	int x;
	int m = getNumberOfLines(f);
	int offset = m * i + j - 1;

	fseek(f, offset * sizeof(int), SEEK_SET);
	fread(&x, sizeof(int), f);
	fseek(f, 0, SEEK_SET);

	return x;
}

void set(FILE *f, int i, int j, int x)
{
	int m = getNumberOfLines(f);
	int offset = m * i + j - 1;
	
	fseek(f, offset * sizeof(int), SEEK_SET);
	fwrite(x, sizeof(int), f);
	fseek(f, 0, SEEK_SET);
}

///////////////////////////////


void sum(FILE *f1, FILE *f2, FILE *f)
{

	int i, j;
	int nrElemente = getNumarElemente(f1);

	int m = getNumarLinii(f1, nrElemente);
	int n = getNumarColoane(nrElemente, m);

	int **A = new(m,n);
	for(i = 0; i < m; i++)
	{
		for(j = 0; j < n; j++)
		{

			A[i][j]= get(f1, i, j) + get(f2, i, j);
			printf("A[%d][%d] = %d\n", i, j, A[i][j]);
			set(f,i,j,A[i][j]);
		}
	}

}

int main(int argc, char **argv)
{

	FILE* f1 = fopen(argv[1], "rb");
	FILE* f2 = fopen(argv[2], "rb");

	FILE* f  = fopen(argv[3], "wb");

	sum(f1, f2, f);
}


