/*
F20. (10 puncte) Implementarea matricilor dreptunghiulare de numere reale ca
 fisiere binare: O matrice va fi stocata intr-un fisier binar continand
 elementele sale pe linii (in format intern), plus o informatie suplimentara
 din care sa se poata deduce numarul de linii si de coloane. Scrieti functii
 pentru urmatoarele operatii:
   void new(m,n)  ==>  creaza o matrice m x n initializata cu 0;
   float get(f,i,j) ==> returneaza elementul de pe pozitia i,j din matricea
                         stocata in fisierul f;
   void set(f,i,j,x) ==> scrie elementul real x pe pozitia i,j in matricea
                         stocata in fisierul f.
 Scrieti programe care folosesc aceste functii pentru a calcula suma
 si produsul a doua matrici. Programele se vor apela sub forma:
   sum f1 f2 f
   pro f1 f2 f
 unde f1, f2 sunt specificatorii fisierelor continand matricile sursa, iar
 f specificatorul fisierului care va contine matricea destinatie. Fisierele
 f1 si f2 vor fi generate in prealabil cu alte programe ajutatatoare (a se
 vedea de exemplu problema F6).
*/
#include<stdio.h>
#include<stdlib.h>


int getNumarElemente(FILE *f)
{
	fseek(f, 0, SEEK_END);
	int length = ftell(f);
	fseek(f, 0, SEEK_SET);

	return length / sizeof(int);
}


int getNumarLinii(FILE *f, int nrElemente)
{
	int offset = nrElemente - 1;
	int nrLinii;

	fseek(f, offset * sizeof(int), SEEK_SET);
	fread(&nrLinii, sizeof(int), 1, f);
	fseek(f, 0, SEEK_SET);
	return nrLinii;
}


int getNumarColoane(int nrElemente, int m)
{
	return (nrElemente - 1) / m;
}


void new(int m, int n, FILE *f)
{
	int **A = (int**) malloc (m * sizeof(int*));

	int i, j;
	for(i = 0; i < m; i++)
	{
		A[i] = (int*) malloc(n * sizeof(int));
		for(j = 0; j < n; j++)
		{
			A[i][j] = 0;
		}
	}

	fwrite(A, sizeof(int), sizeof(A)/sizeof(int), f);
	fwrite(&m, sizeof(int), 1, f);
}

int get(FILE *f, int i, int j)
{
	int x;
	int total = getNumarElemente(f);
	int m = getNumarLinii(f, total);
	int offset = m * i + j;

	fseek(f, offset * sizeof(int), SEEK_SET);
	fread(&x, sizeof(int), 1, f);
	fseek(f, 0, SEEK_SET);

	return x;
}


void set(FILE *f, int i, int j, int x)
{
	
	int offset = 3 * i + j;
	
	fseek(f, offset * sizeof(int), SEEK_SET);
	fwrite(&x, sizeof(int), 1, f);
	fseek(f, 0, SEEK_SET);
}


void print (FILE *f)
{
	int total = getNumarElemente(f);
	int m = getNumarLinii(f, total);
	int n = getNumarColoane(total, m);


	int i, j;
	int curr;
	for(i = 0; i < n; i++)
		for(j = 0; j < m; j++)
		{
			curr = get(f, i, j);
			printf("A[%d][%d] = %d\n", i, j, curr);
			//A[i][j] = curr;
		}
}

void write(FILE* f, int A[][])
{
	int i, j;

	for(i = 0; i < 3; i++)
		for(j = 0; j < 2; j++)
		{
			set(f, i, j, A[i][j]);
			if(i == 3  && j == 2)
				set(f, i, j+1, i);
		}

}
int main(int argc, char **argv)
{
	

	FILE *f_bin = fopen(argv[1], "rb");

	int total = getNumarElemente(f_bin);
	int m = getNumarLinii(f_bin, total);
	int n = getNumarColoane(total, m);
	
	printf("Numar elemente: %d\n", total);
	printf("Numar linii: %d\n", m);
	printf("Numar coloane: %d\n", n);
	printf("Matricea este de forma A[%d][%d]\n", m, n);
	print(f_bin);


	FILE *g_bin = fopen(argv[2], "wb");
	new(3,2, g_bin);

	
	int A[3][2] = { {1, 2}, {4,5}, {4,5}};
	write(g_bin, A);
	g_bin = fopen(argv[2], "rb");
	print(g_bin);
	fclose(f_bin);
	fclose(g_bin);
	 
	
	
	return 0;
}


