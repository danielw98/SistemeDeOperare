/*
F6. (0.5 puncte) Scrieti un program care converteste un fisier (text) cu
 reprezentari externe zecimale de intregi intr-un fisier (binar) cu
 reprezentarile lor interne. Specificatorii fisierelor sunti dati ca
 argumente in linia de comanda.
*/

//#include "conversieFisiere.h"
#include<stdio.h>
#include<stdlib.h>

void print(int* arr, int n)
{
	int i;
	printf("Vectorul: ");
	for(i = 0; i < n; i++)
		printf("%d ", arr[i]);
	printf("\n");
}



int countNumbers(FILE* f)
{
	int count = 0;
	int x;

	while(fscanf(f,"%d ",&x) == 1)
	{
		//printf("%d ", x);
		count++;
	}

	fseek(f,0,SEEK_SET);

	return count;
}



int* readFile(FILE* f, int n)
{
	int i = 0;
	int *buffer = (int*) malloc (n * sizeof(int));
	
	while(!feof(f))
	{
		fscanf(f, "%d ", &buffer[i++]);
		
	}

	print(buffer, n);

	return buffer;
}


void writeFile(FILE* f_bin, int* buffer, int n)
{
	fwrite(buffer, n * sizeof(int), 1, f_bin);
}


void convertFile(FILE *f, FILE *f_bin)
{
	int n = countNumbers(f);
	int* buffer = readFile(f, n);
	
	writeFile(f_bin, buffer, n);
	printf("Conversie facuta cu succes.\n");
}



int main(int argc, char **argv)
{

	FILE *f = fopen(argv[1], "r");
	FILE *f_bin = fopen(argv[2], "wb");
	
	convertFile(f, f_bin);

	fclose(f);
	fclose(f_bin);

	return 0;
}
