#include<stdlib.h>
#include<string.h>
#include<stdio.h>
void main(int argc, char **argv)
{
	char *sursa = argv[1];
	char *destinatie = "PATH=$PATH:";
	printf("Sursa: %s\nDestinatie: %s\n", sursa, destinatie);
	strcat(destinatie, sursa);
	
	printf("Comanda: %s\n\n", destinatie);
	//system(destinatie);
}
