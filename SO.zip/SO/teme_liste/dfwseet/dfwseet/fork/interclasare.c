/*
A10. (6 puncte) Scrieti un program care sa sorteze prin interclasare un fisier
 de caractere in maniera descrisa mai jos.
  Sortarea prin interclasare presupune impartirea sirului in doua jumatati,
 sortarea fiecarei parti prin aceeasi metoda (deci recursiv), apoi 
 interclasarea celor doua parti (care sunt acum sortate).
  Programul va lucra astfel: se imparte sirul in doua, se genereaza doua 
 procese fiu (fork) care sorteaza cele doua jumatati in paralel, tatal ii 
 asteapta sa se termine (wait sau waitpid), apoi interclaseaza jumatatile.
 Nu se vor folosi fisiere auxiliare. 
*/

#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h> 
#include <stdlib.h>

void combina(char *v, int st, int mij, int dr)
{

	int i, j, k;
	printf("Apel combina(v, %d, %d, %d)\n", st, mij, dr);
	int n = dr - st + 1;
	char *c = (char*) malloc (n * sizeof(char));
	i = st;
	j = mij + 1;
	k = 0;

	while(i <= mij && j <= dr)
	{
		if(v[i] < v[j])
			c[k++] = v[i++];		
		else
			c[k++] = v[j++];
	}

	while(i <= mij && j <= dr)
	{
		if(v[i] < v[j])
			c[k++] = v[i++];
		else
			c[k++] = v[j++];
	}

	while(i <= mij)
		c[k++] = v[i++];	

	while(j <= dr)
		c[k++] = v[j++];
	
	for(i = 0; i < n; i++)
		v[st+i] = c[i];

}
void divide(char *v, int st, int dr)
{
	
	if(st < dr)
	{

		printf("Apel divide(v, %d, %d)\n", st, dr);
		int mij = st + (dr-st)/2;
		pid_t pid[2];

		int i;
		for(i = 0; i < 1; i++)
		{
			pid[i] = fork();
 
			if(pid[i]==0)
			{
				printf("Procesul copil %d\n", pid[i]);
				divide(v, st, mij);
				exit(EXIT_SUCCESS);
			}
			else if(pid[i] < 0)
			{
				perror("fork() failed");
				
			}
		}
		//pid[1] = fork(); 
		divide(v, mij+1, dr);
		//wait(pid[0]);
		//wait(pid[1]);
		combina(v, st, mij, dr);
	}
}


void initializeaza(int fd)
{

	size_t size = lseek(fd, (off_t) 0, SEEK_END);
	lseek(fd, (off_t) 0, SEEK_SET);
	
	char *buf = (char*) malloc(size * sizeof(char));
	read(fd, buf, size);
	printf("Buffer-ul este: %s", buf);

	divide(buf, 0, size-1);
	printf("\n\nBuffer-ul sortat: %s\n\n", buf);
}



int main(int argc, char **argv)
{

	int fd = open(argv[1], O_RDWR);
	initializeaza(fd);
	
	return 0;
}
