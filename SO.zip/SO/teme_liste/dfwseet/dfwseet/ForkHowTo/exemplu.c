#include <stdio.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h> 
#include <stdlib.h>
#include <sys/wait.h>
int main()
{
	pid_t child = fork();
	
	if(child < 0)
	{
		perror("fork() error");
		exit(-1);
	}

	
	if(child != 0)
	{
		printf("I'm the parent %d, my child is %d\n", getpid(), child);
		wait(NULL); // wait for child process to join w/ parent
	}
	else
	{
		printf("I'm the child %d, my parent is %d\n", getpid(), getppid());
		execl("/bin/echo", "echo", "Hello, World", NULL);
	}

	return 0;
}
