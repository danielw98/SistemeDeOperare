#include<stdio.h>
#include<string.h>
#include<unistd.h>
#include<fcntl.h>

int main ()
{

	int fd[2];
	char buf1[12] = "hello world";
	char buf2[12];
	
	fd[0] = open("foobar.txt", O_RDWR);
	fd[1] = open("foobar.txt", O_RDWR);

	write(fd[0], buf1, strlen(buf1)); // scriu hello world in fisierul retinut de fd[0]
	write(1, buf2, read(fd[1], buf2, 12)); // scriu hello world la stdout din buf-ul citit
	// din fisierul 1, am inclusiv lungimea

	close(fd[0]);
	close(fd[1]);

	return 0;

}
