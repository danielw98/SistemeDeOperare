#include<stdio.h>
void main(){
 int i=65; 
 printf("%d %x %c\n",i,i,i);
}