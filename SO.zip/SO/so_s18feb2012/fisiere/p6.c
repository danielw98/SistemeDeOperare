#include<stdio.h>
int a,b; float c; char x[10],y[10],z[10];
void main(){
 scanf("%d%d%f",&a,&b,&c); printf("%d %d %f\n",a,b,c);
 scanf("%s%s%s",x,y,z); printf("%s %s %s\n",x,y,z);
}