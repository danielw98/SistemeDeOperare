#include<stdio.h>
int a; char c;
void main(){
 scanf("%d%c",&a,&c); printf("%d %c\n",a,c);
}