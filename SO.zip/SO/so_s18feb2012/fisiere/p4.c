#include<stdio.h>
void main(){
 int i=16640; /* = 0 + 65*256 + 0*256^2 + 0*256^3 */
 scanf("%c",&i); 
 printf("%d %c\n",i,i);
}