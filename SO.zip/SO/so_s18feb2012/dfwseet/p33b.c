#include<stdio.h>
int main(){while(1)printf("A"); fflush(stdout); return 0;}
/* Program auxiliar pentru "p33a"; nu se lanseaza direct */