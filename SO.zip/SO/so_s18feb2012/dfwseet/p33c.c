#include<stdio.h>
#include<unistd.h>
int main(){char c;
  while(1){scanf("%c",&c); printf("%c\n",c); sleep(1);}
  return 0;
}
/* Program auxiliar pentru "p33a"; nu se lanseaza direct */
