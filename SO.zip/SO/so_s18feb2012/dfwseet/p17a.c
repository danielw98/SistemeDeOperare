#include<stdio.h>
#include<stdlib.h>
int main(){printf("A"); fflush(stdout); system("./p17b"); return 0;}
/* Necesita programul p17b.
   Utilizare:
   Lansam:
     p17a > f
   In final fisierul "f" va contine:
     AB
*/
