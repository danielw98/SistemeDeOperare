struct stat{
 
 mode_t st_mode;   /* tipul fisierului si drepturile de acces */
 
 uid_t  st_uid;    /* user ID-ul proprietarului fisierului */
 
 off_t  st_size;   /* dimensiunea fisierului (daca are sens) */

 time_t st_atime;  /* momentul ult. acces la fis. (citire, scriere) */
 time_t st_mtime;  /* momentul ult. modificari a fis. (scriere) */
 
};
